# Зависимости и распространение

Версии и contentHash NuGet фиксируются в `packages.lock.json`. TLS, подписи пакетов и хеши не отключаются. Исходный код внешних оптимизаторов, Mem Reduct и других приложений не включён и не запускается.

| Компонент | Версия | Назначение | Лицензия / первичный источник |
|---|---|---|---|
| .NET SDK | 10.0.403 | Инструменты сборки, не требуется пользователю EXE | https://github.com/dotnet/sdk |
| .NET / Windows Desktop runtime | 10.0.14 | Self-contained runtime | MIT и third-party notices: https://github.com/dotnet/runtime и https://github.com/dotnet/wpf |
| System.Management | 10.0.0 | Чтение WMI | MIT: https://www.nuget.org/packages/System.Management/10.0.0 |
| System.CodeDom | 10.0.0 | Транзитивная зависимость System.Management | MIT: https://www.nuget.org/packages/System.CodeDom/10.0.0 |
| Microsoft.NET.Test.Sdk | 17.12.0 | Только тестирование | MIT: https://www.nuget.org/packages/Microsoft.NET.Test.Sdk/17.12.0 |
| xUnit | 2.9.3 | Только тестирование | Apache-2.0: https://github.com/xunit/xunit |
| xunit.runner.visualstudio | 3.0.1 | Только тестирование | Apache-2.0: https://github.com/xunit/visualstudio.xunit |

Лицензия собственного кода пока не выбрана владельцем репозитория; открытая лицензия за него не объявляется. Сертификат издателя отсутствует. Сборка не подписана Authenticode. Подтверждённой матрицы поддерживаемых Windows-сборок пока нет.

Уведомления runtime и NuGet должны оставаться в `licenses/` распространяемой папки. Перечень всех транзитивных тестовых зависимостей зафиксирован в lock-файле тестового проекта; они не включаются в portable приложение.
